package com.example.board.mapper;

import com.example.board.common.dto.SearchDto;
import com.example.board.domain.post.PostRequest;
import com.example.board.domain.post.PostResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PostMapper {

    void save(PostRequest params);

    PostResponse findById(Long id);

    void update(PostRequest params);
    void deleteById(Long id);

    /**
     * 게시글 리스트 조회
     * @return 게시글 리스트
     */
    List<PostResponse> findAll(SearchDto params);

    /**
     * 게시글 수 카운팅
     * @return 게시글 수
     */
    int count(SearchDto params);

}
