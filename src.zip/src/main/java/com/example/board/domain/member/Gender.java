package com.example.board.domain.member;

public enum Gender {

    M, F
}
